import pgzrun
import random

WIDTH = 600
HEIGHT = 350
bg=[]
upcounter=0
STATE=0
TITLE = "Main Menu"

for i in range(4):
    bg.append(Actor("bg.png"))
    bg[i].pos=(i*600),350/2
    
lane1=180
lane2=240
lane3=360
anita=[]
for i in range(9):
    anita.append(Actor("anitasprites/tile00"+str(i)+".png"))
    anita[i].pos=50,lane1

"the lines above need to be done for all characters"
"the chosen sprite will be stored in MC"
natasha=[]
for i in range(9):
    natasha.append(Actor("natashasprites/tile00"+str(i)+".png"))
    natasha[i].pos=50,lane1
joe=[]
for i in range(9):
    joe.append(Actor("joesprites/tile00"+str(i)+".png"))
    joe[i].pos=50,lane1

emilie=[]
for i in range(9):
    emilie.append(Actor("emiliesprites/tile00"+str(i)+".png"))
    emilie[i].pos=50,lane1

harrison=[]
for i in range(9):
    harrison.append(Actor("harrisonsprites/tile00"+str(i)+".png"))
    harrison[i].pos=50,lane1

mark=[]
for i in range(9):
    mark.append(Actor("marksprites/tile00"+str(i)+".png"))
    mark[i].pos=50,lane1

callum=[]
for i in range(9):
    callum.append(Actor("callumsprites/tile00"+str(i)+".png"))
    callum[i].pos=50,lane1

jack=[]
for i in range(9):
    jack.append(Actor("jacksprites/tile00"+str(i)+".png"))
    jack[i].pos=50,lane1

rachel=[]
for i in range(9):
    rachel.append(Actor("rachelsprites/tile00"+str(i)+".png"))
    rachel[i].pos=50,lane1
    
emma=[]
for i in range(9):
    emma.append(Actor("emmasprites/tile00"+str(i)+".png"))
    emma[i].pos=50,lane1

adam=[]
for i in range(9):
    adam.append(Actor("adamsprites/tile00"+str(i)+".png"))
    adam[i].pos=50,lane1

clara=[]
for i in range(9):
    clara.append(Actor("clarasprites/tile00"+str(i)+".png"))
    clara[i].pos=50,lane1
megan=[]
for i in range(9):
    megan.append(Actor("megansprites/tile00"+str(i)+".png"))
    megan[i].pos=50,lane1
    
MC=anita

MCinlane=1
coins=[]
boogies=[]
score=0
RED = 200, 0, 0
for i in range (8):
    coins.append (Actor("student "+str((i+1))+".png"))
    coins[i].x=600+random.randrange(0,2000,50)
    coins[i].y=180+random.randrange(0,180, 60)
    
ellis=Actor("ellis.png")
ellis.x=600+random.randrange(0,2000,50)
ellis.y=180+random.randrange(0,180, 60)

for i in range (3):
    boogies.append (Actor("taylor.png"))
    boogies[i].x=600+random.randrange(0,2000,50)
    boogies[i].y=180+random.randrange(0,180, 60)
    
for i in range (3):
    boogies.append (Actor("telephone box.png"))
    boogies[i].x=600+random.randrange(0,2000,50)
    boogies[i].y=180+random.randrange(0,180, 60)
    
    
for i in range (3):
    boogies.append (Actor("lamp.png"))
    boogies[i].x=600+random.randrange(0,2000,50)
    boogies[i].y=180+random.randrange(0,180, 60)

for i in range (3):
    boogies.append (Actor("laundry bag.png"))
    boogies[i].x=600+random.randrange(0,2000,50)
    boogies[i].y=180+random.randrange(0,180, 60)

startbutton = Actor('startbutton', (310, 175))
joe1 = Actor("pixilart-drawing.png")
emilie1 = Actor("pixilart-drawing 3.png")
harrison1 = Actor("harrison.png")
mark1 = Actor("mark.png")
callum1 = Actor("callum.png")
jack1 = Actor("jack.png")
adam1 = Actor("adam.png")
anita1 = Actor("anita.png")
clara1 = Actor("clara.png")
rachel1 = Actor("rachel.png")
emma1 = Actor("emma.png")
megan1 = Actor("megan.png")
natasha1 = Actor("natasha.png")

Gameover=Actor("game over screen.png")

lanyardbag= Actor("lanyard bag.png")
lanyardbag.x=600+random.randrange(0,2000,50)
lanyardbag.y=180+random.randrange(0,180, 60)
lanyard= Actor("lanyard.png")
lanyard.pos=40,10
anitacounter=0
def draw():
    global anitacounter,upcounter,STATE
    if STATE==3:
        Gameover.draw()
    if STATE==0:
        
        screen.clear()
        screen.fill(('White'))
        startbutton.draw()
        screen.blit('titletext',(78, 5))
    if (STATE==1):
        
        if (upcounter%9==0):
            anitacounter=anitacounter+1
        for i in bg:
            i.draw()
        screen.draw.text(str(score), (20, 10), color="red", fontsize=18)
        lanyard.draw()
        lanyardbag.draw()
        for i in coins:
            i.draw()
        for i in boogies:
            i.draw()
        MC[anitacounter%8].draw()
        ellis.draw()
    if STATE==2:
        screen.clear()
        screen.fill("firebrick")
        screen.draw.text("Choose your character!", center=(WIDTH / 2, HEIGHT / 2 - 120), fontsize=30, color="white")
        screen.draw.filled_rect(Rect(WIDTH / 2 - 180, HEIGHT / 2 - 90, 100, 80), "grey")
        screen.draw.filled_rect(Rect(WIDTH / 2 - 180, HEIGHT / 2 - 5, 100, 80), "grey")
        screen.draw.filled_rect(Rect(WIDTH / 2 - 180, HEIGHT / 2 + 80, 100, 80), "grey")
        screen.draw.filled_rect(Rect(WIDTH / 2 + 70, HEIGHT / 2 - 100, 100, 80), "grey")
        screen.draw.filled_rect(Rect(WIDTH / 2 + 70, HEIGHT / 2 - 15, 100, 90), "grey")
        screen.draw.filled_rect(Rect(WIDTH / 2 + 70, HEIGHT / 2 + 80, 100, 85), "grey")
        screen.draw.filled_rect(Rect(WIDTH / 2 - 55, HEIGHT / 2 - 95, 100, 80), "grey")
        screen.draw.filled_rect(Rect(WIDTH / 2 - 55, HEIGHT / 2 - 7, 100, 80), "grey")
        screen.draw.filled_rect(Rect(WIDTH / 2 - 55, HEIGHT / 2 + 82, 100, 80), "grey")
        screen.draw.filled_rect(Rect(WIDTH / 2 - 290, HEIGHT / 2 - 90, 100, 80), "grey")
        screen.draw.filled_rect(Rect(WIDTH / 2 - 290, HEIGHT / 2 - 5, 100, 80), "grey")
        screen.draw.filled_rect(Rect(WIDTH / 2 + 190, HEIGHT / 2 - 100, 100, 80), "grey")
        screen.draw.filled_rect(Rect(WIDTH / 2 + 190, HEIGHT / 2 - 10, 100, 80), "grey")

        joe1.pos = (160, 119)
        joe1.draw()
    
        emilie1.pos = (420, 200)
        emilie1.draw()

        harrison1.pos = (165, 210)
        harrison1.draw()
    
        mark1.pos = (165, 295)
        mark1.draw()
    
        callum1.pos = (420, 115)
        callum1.draw()
        
        jack1.pos = (420, 300)
        jack1.draw()
        
        adam1.pos = (290, 120)
        adam1.draw()
        
        anita1.pos = (290, 210)
        anita1.draw()
        
        clara1.pos = (290, 297)
        clara1.draw()
          
        rachel1.pos = (50, 125)
        rachel1.draw()
        
        emma1.pos = (50, 210)
        emma1.draw()
        
        megan1.pos  = (542, 115)
        megan1.draw()
        
        natasha1.pos = (535, 205)
        natasha1.draw()
   
    
def update():
    global MCinlane,upcounter,score,STATE,MC

    if score<0:
        STATE=3
        
    
    if STATE==1:
        upcounter=upcounter+1
        ellis.x=ellis.x-3
        for i in bg:
            i.x=i.x-3
            if (i.x<-600):
                i.x=600*2
        for i in coins:
            i.x=i.x-3
        for i in boogies:
            i.x=i.x-3
        lanyardbag.x=lanyardbag.x-3
        for j in MC:
            
            if ellis.x<-100:
                ellis.x=600+random.randrange(0,1000,50)
                ellis.y=180+random.randrange(0,180, 60)
            for i in coins:
            
                if (i.x<-20):
                    i.x=600+random.randrange(0,1000,50)
                    
                    score=score-1
                if j.colliderect(i):
                    i.x=600+random.randrange(0,1000,50)
                    score=score+5
                    print(score)
            
            for i in boogies:
                
                if (i.x<-20):
                    i.x=600+random.randrange(0,1000,50)
                    i.y=180+random.randrange(0,180, 60)
                
                if j.colliderect(i):
                    i.x=600+random.randrange(0,1000,50)
                    i.y=180+random.randrange(0,180, 60)
                    score=score-2
                    print(score)
            if j.colliderect(ellis):
                score=score-50
                print(score)
                ellis.x=600+random.randrange(0,1000,50)
                ellis.y=180+random.randrange(0,180, 60)
            
            if j.colliderect(lanyardbag):
                score=score+50
                lanyardbag.x=600+random.randrange(0,1000,50)
                lanyardbag.y=180+random.randrange(0,180, 60)
        if (upcounter%7==0):
            if keyboard.up and MCinlane!=1:
                for i in MC:
                    i.y=i.y-60
            
                MCinlane=MCinlane-1
        
            if keyboard.down and MCinlane != 3:
                for i in MC:
                    i.y=i.y+60
                MCinlane=MCinlane+1
        
def on_mouse_down(pos, button):
    global STATE,MC
    
    
    if STATE==2:

        if button == mouse.LEFT and joe1.collidepoint(pos):
            MC=joe
            STATE=1
            print(STATE)
        
        if button == mouse.LEFT and emilie1.collidepoint(pos):
            MC=emilie
            STATE=1
            print(STATE)
    
        if button == mouse.LEFT and harrison1.collidepoint(pos):
            MC=harrison
            STATE=1
            print(STATE)
        
        if button == mouse.LEFT and mark1.collidepoint(pos):
            MC=mark
            STATE=1
            print(STATE)
        
        if button == mouse.LEFT and callum1.collidepoint(pos):
            MC=callum
            STATE=1
            print(STATE)
        
        if button == mouse.LEFT and adam1.collidepoint(pos):
            MC=adam
            STATE=1
            print(STATE)
        
        if button == mouse.LEFT and anita1.collidepoint(pos):
            MC=anita
            STATE=1
            print(STATE)
    
        if button == mouse.LEFT and clara1.collidepoint(pos):
            MC=clara
            STATE=1
            print(STATE)
        
        if button == mouse.LEFT and rachel1.collidepoint(pos):
            MC=rachel
            STATE=1
            print(STATE)
        
        if button == mouse.LEFT and emma1.collidepoint(pos):
            MC=emma
            STATE=1
            print(STATE)
        
        if button == mouse.LEFT and megan1.collidepoint(pos):
            MC=megan
            STATE=1
            print(STATE)
        
        if button == mouse.LEFT and natasha1.collidepoint(pos):
            MC=natasha
            STATE=1
            print(STATE)
    if button == mouse.LEFT and startbutton.collidepoint(pos) and STATE==0:
        STATE=2
        print(STATE)
        
pgzrun.go()
